"""Curated, bilingual knowledge-center content for Infinity Converter."""

BLOG_POSTS = [
    {
        "slug": "word-to-pdf-without-losing-formatting",
        "title_ar": "كيف تحوّل Word إلى PDF بدون ما تخسر التنسيق؟",
        "title_en": "How to turn Word into PDF without losing your formatting",
        "description_ar": "دليل عملي لفهم أكثر أسباب تغيّر التنسيق عند تحويل ملفات Word إلى PDF، وكيف تقلل المفاجآت قبل الإرسال أو الطباعة.",
        "description_en": "A practical guide to the most common formatting problems when turning Word documents into PDF, and how to avoid surprises before sharing or printing.",
        "category_ar": "المستندات",
        "category_en": "Documents",
        "minutes": 6,
        "tool": "/tools/word-to-pdf",
        "tool_label_ar": "جرّب Word إلى PDF",
        "tool_label_en": "Try Word to PDF",
        "sections": [
            ("قبل التحويل: المشكلة غالبًا ليست في PDF", "ملف Word يتعامل مع الصفحة بطريقة مرنة أكثر مما نتخيل. نوع الخط، حجم الورق، الهوامش، تباعد الفقرات وحتى وجود صورة قريبة من نهاية الصفحة كلها أشياء قد تغيّر شكل المستند عند التصدير. لذلك إذا ظهر لك اختلاف بسيط بعد التحويل، فهذا لا يعني أن ملف PDF تالف؛ غالبًا يعني أن هناك عنصرًا في المستند الأصلي يحتاج إلى ضبط."),
            ("ابدأ بحجم الصفحة الصحيح", "إذا كان المستند مخصصًا للطباعة، اجعل حجم الصفحة في Word مطابقًا لما تتوقعه في PDF. في أغلب المستندات العربية سيكون A4 هو الاختيار الطبيعي. بعدها راجع الهوامش، خصوصًا إذا كان عندك جدول عريض أو ترويسة طويلة. هذه الخطوة الصغيرة تمنع كثيرًا من انتقال سطر إلى صفحة جديدة."),
            ("الخطوط والصور: مصدر المفاجآت الأشهر", "استخدم خطوطًا شائعة ومثبتة على جهازك، ولا تعتمد على خط غريب إذا كان المستند سيُفتح على أجهزة مختلفة. وبالنسبة للصور، لا تضعها في أماكن حساسة جدًا بين فقرات متحركة. إذا كان المستند رسميًا، راجع أول صفحة وآخر صفحة بعد التحويل؛ غالبًا هناك تظهر المشكلة إن كانت موجودة."),
            ("وماذا عن ملفات DOC القديمة؟", "إذا كان عندك ملف DOC قديم من إصدار قديم من Microsoft Word، فلا تحتاج إلى إعادة كتابته لمجرد التحويل. Infinity Converter يدعم DOC وDOCX في مسار Word إلى PDF، لذلك تستطيع تجربة الملف كما هو أولًا. وإذا كان المستند يحتوي على عناصر قديمة جدًا أو خطوطًا خاصة، فالمراجعة البصرية بعد التحويل تظل خطوة ذكية."),
            ("قاعدة بسيطة قبل الإرسال", "افتح الـPDF الناتج على جهاز مختلف إن كان المستند مهمًا. جرّب البحث داخل النص، افحص أرقام الصفحات، وانظر إلى الجداول والصور والترويسة. خمسون ثانية من المراجعة قد توفر عليك إرسال ملف رسمي بتنسيق غير مقصود."),
        ],
    },
    {
        "slug": "pdf-to-word-when-it-works-best",
        "title_ar": "متى يكون تحويل PDF إلى Word فكرة ممتازة؟ ومتى لا يكون؟",
        "title_en": "When is PDF to Word a great idea — and when isn't it?",
        "description_ar": "ليس كل PDF متشابهًا. تعرّف على الفرق بين PDF النصي والملف الممسوح ضوئيًا، ومتى تحصل على مستند قابل للتحرير فعلًا.",
        "description_en": "Not all PDFs are alike. Learn the difference between text PDFs and scanned files, and when you can expect a genuinely editable document.",
        "category_ar": "PDF",
        "category_en": "PDF",
        "minutes": 7,
        "tool": "/tools/pdf-to-docx",
        "tool_label_ar": "جرّب PDF إلى Word",
        "tool_label_en": "Try PDF to Word",
        "sections": [
            ("السؤال الأول: هل النص داخل PDF نص فعلًا؟", "افتح الملف وحاول تحديد كلمة بالماوس أو لمسها على الجوال. إذا استطعت تحديد الحروف ونسخها، فأنت أمام PDF نصي، وتحويله إلى Word عادةً يكون أسهل. أما إذا كانت كل الصفحة تتصرف كصورة واحدة، فغالبًا تحتاج إلى OCR قبل أن تتوقع نصًا قابلًا للتحرير."),
            ("لماذا تتغير الجداول؟", "PDF ممتاز في حفظ الشكل النهائي، لكنه لا يخزن المستند دائمًا بالطريقة التي يفكر بها Word. قد يرى PDF جدولًا كأشكال وخطوط ونصوص موضوعة في أماكن دقيقة، بينما يريد Word بناء جدول حقيقي. لهذا قد تحتاج بعض الجداول إلى ترتيب بسيط بعد التحويل، خصوصًا الجداول المعقدة."),
            ("الملفات العربية تحتاج نظرة إضافية", "العربية تجمع بين اتجاه الكتابة من اليمين إلى اليسار وترتيب بصري مختلف عن النص اللاتيني. إذا كان المستند عربيًا، راجع العناوين، التعدادات والجداول بعد التحويل. لا تعتمد على أول فقرة فقط؛ جرّب صفحة فيها جدول أو أكثر من عمود لأن هذه الحالات تكشف جودة التحويل بسرعة."),
            ("إذا كان PDF عبارة عن مسح ضوئي", "هنا يدخل OCR. البرنامج يحتاج أولًا إلى قراءة الحروف من الصورة، وبعدها يبني نصًا جديدًا. جودة النتيجة تعتمد على دقة المسح، وضوح الخط، ميل الصفحة، وجود خلفية أو ضوضاء، واللغة المستخدمة. لذلك لا تتوقع من صورة مهزوزة نتيجة مثالية من ضغطة واحدة."),
            ("متى أنصحك بالتحويل؟", "إذا كنت تحتاج تعديل نص موجود، استخراج فقرات، أو إعادة استخدام جزء من مستند، فالتحويل يوفر وقتًا كبيرًا. أما إذا كان هدفك فقط الاحتفاظ بالشكل كما هو، فابقَ على PDF؛ فهو أصلًا الصيغة المناسبة للمشاركة والطباعة."),
        ],
    },
    {
        "slug": "pdf-compression-without-making-it-ugly",
        "title_ar": "ضغط PDF: كيف تصغّر الملف بدون ما يصير شكله سيئ؟",
        "title_en": "PDF compression: how to make a file smaller without ruining it",
        "description_ar": "فهم بسيط لما يحدث عند ضغط PDF، ولماذا الصور هي أول شيء يرفع الحجم، وكيف تختار مستوى ضغط منطقي.",
        "description_en": "A simple look at what makes PDFs large, why images are usually the main culprit, and how to choose a sensible compression level.",
        "category_ar": "PDF",
        "category_en": "PDF",
        "minutes": 5,
        "tool": "/tools/compress-pdf",
        "tool_label_ar": "جرّب ضغط PDF",
        "tool_label_en": "Try PDF compression",
        "sections": [
            ("ليس كل PDF يحتاج ضغطًا قويًا", "أحيانًا يكون الملف كبيرًا لأن بداخله صور عالية الدقة، وأحيانًا يكون الحجم بسبب الخطوط المضمنة أو عناصر أخرى. الضغط القوي قد يقلل الحجم فعلًا، لكنه قد يجعل الصور الصغيرة غير مريحة للقراءة. لذلك الأفضل أن تبدأ بمستوى معقول بدل اختيار أقصى ضغط مباشرة."),
            ("اسأل نفسك: أين سيُستخدم الملف؟", "ملف سيُرسل بالبريد ليس مثل ملف سيُطبع في مطبعة. للقراءة على الجوال، يمكن غالبًا تقليل دقة الصور أكثر مما يمكن في ملف مخصص للطباعة. إذا كان الملف يحتوي على مخططات أو لقطات شاشة، حافظ على وضوح النص داخل الصور؛ هذا أهم من الوصول إلى أصغر حجم ممكن."),
            ("اختبر الصفحة الأسوأ", "بعد الضغط، لا تكتفِ بمشاهدة الغلاف. انتقل إلى الصفحة التي فيها أصغر نص أو أكثر صورة تفصيلًا. كبّرها، جرّب البحث، وتأكد أن الرسومات لم تتحول إلى ضباب. إذا كانت هذه الصفحة جيدة، فغالبًا بقية الملف بخير."),
            ("الحجم المثالي ليس رقمًا سحريًا", "لا توجد قاعدة تقول إن كل PDF يجب أن يكون أقل من 1 ميجابايت أو 5 ميجابايت. الهدف الحقيقي هو الوصول إلى أصغر ملف ما زال يحقق الغرض منه. ملف 8 ميجابايت واضح أفضل من ملف 1 ميجابايت لا يمكن قراءة محتواه."),
            ("نصيحة عملية", "احتفظ بالنسخة الأصلية قبل الضغط، خصوصًا للملفات المهمة. اجعل النسخة المضغوطة نسخة مشاركة، وليس النسخة الوحيدة التي تملكها. بهذه الطريقة تستطيع العودة إلى الجودة الأصلية إذا احتجت طباعة عالية الجودة لاحقًا."),
        ],
    },
    {
        "slug": "ocr-for-scanned-arabic-pdfs",
        "title_ar": "OCR للملفات العربية: لماذا ينجح أحيانًا ويفشل أحيانًا؟",
        "title_en": "OCR for Arabic documents: why it works sometimes and fails sometimes",
        "description_ar": "شرح واقعي لتقنية OCR وكيف تتعامل مع المستندات العربية الممسوحة ضوئيًا، مع خطوات ترفع جودة النص المستخرج.",
        "description_en": "A realistic guide to OCR for scanned Arabic documents, including the practical steps that improve extracted text quality.",
        "category_ar": "OCR",
        "category_en": "OCR",
        "minutes": 7,
        "tool": "/tools/pdf-ocr",
        "tool_label_ar": "جرّب أدوات OCR",
        "tool_label_en": "Try OCR tools",
        "sections": [
            ("OCR ليس تحويل صورة إلى نص سحريًا", "عندما يكون المستند ممسوحًا ضوئيًا، الحروف التي تراها ليست نصًا حقيقيًا داخل الملف؛ هي بكسلات. OCR يحاول التعرف على هذه البكسلات وبناء نص جديد. لذلك النتيجة تتأثر بجودة الصورة قبل أي شيء آخر."),
            ("الوضوح أهم من حجم الملف", "صورة واضحة ومستقيمة بدقة مناسبة تعطي OCR فرصة أفضل بكثير. الصفحات المائلة، الظلال، الخلفيات الملونة، والخطوط الباهتة تجعل المهمة أصعب. إذا كان لديك خيار إعادة المسح، اجعل الصفحة مستقيمة ونظيفة بدل الاعتماد على معالجة لاحقة فقط."),
            ("العربية لها تحدياتها الخاصة", "اتصال الحروف، النقاط، الحركات، والخلط بين العربية والأرقام والإنجليزية كلها أمور قد تربك التعرف. لهذا من الطبيعي أن تحتاج إلى مراجعة النص المستخرج، خصوصًا أسماء الأشخاص والأرقام والتواريخ. OCR ممتاز لتقليل العمل اليدوي، لكنه ليس تصريحًا بأن كل حرف أصبح صحيحًا بنسبة 100%."),
            ("أفضل استخدام عملي لـOCR", "استخدمه عندما تريد جعل ملف قديم قابلًا للبحث، أو عندما تحتاج استخراج جزء كبير من نص بدل كتابته يدويًا. وإذا كان هدفك وثيقة نهائية للنشر، اعتبر النص الناتج مسودة تحتاج مراجعة، لا نسخة أصلية لا تُراجع."),
            ("اختبار سريع للجودة", "خذ صفحة واحدة من الملف وجربها أولًا. ابحث عن كلمة واضحة، رقم طويل، وعنوان. إذا كانت الثلاثة تظهر بشكل صحيح، فهذه إشارة جيدة. وإذا ظهرت أخطاء كثيرة من أول صفحة، فمن الأفضل تحسين الصور أو ضبط إعدادات اللغة قبل معالجة المستند كاملًا."),
        ],
    },
    {
        "slug": "jpg-png-webp-which-image-format",
        "title_ar": "JPG أم PNG أم WebP؟ اختيار الصيغة أسهل مما تتوقع",
        "title_en": "JPG, PNG, or WebP? Choosing the right image format is easier than it looks",
        "description_ar": "دليل سريع لكن عملي لاختيار صيغة الصورة حسب طبيعتها: صور فوتوغرافية، شعارات، لقطات شاشة، أو صور مخصصة للويب.",
        "description_en": "A practical guide to choosing an image format for photos, logos, screenshots, and web delivery.",
        "category_ar": "الصور",
        "category_en": "Images",
        "minutes": 5,
        "tool": "/tools/image-to-webp",
        "tool_label_ar": "افتح أدوات الصور",
        "tool_label_en": "Open image tools",
        "sections": [
            ("JPG: ممتاز للصور الفوتوغرافية", "إذا كانت الصورة مليئة بتدرجات وألوان كثيرة، مثل صورة كاميرا أو منظر، فـJPG غالبًا خيار عملي. يستخدم ضغطًا يفقد جزءًا من البيانات، لكنه يستطيع إنتاج حجم صغير مناسب للمشاركة والويب."),
            ("PNG: عندما تحتاج التفاصيل الحادة والشفافية", "الشعارات، الرسومات البسيطة، وبعض لقطات الشاشة تستفيد من PNG، خصوصًا إذا كانت الحواف الحادة والشفافية مهمة. لكن PNG قد يصبح ضخمًا مع الصور الفوتوغرافية الكبيرة، وهنا قد لا يكون الاختيار الأفضل."),
            ("WebP: خيار قوي للويب", "WebP صُمم ليقدم ضغطًا جيدًا مع جودة مناسبة للويب، لذلك يمكن أن يقلل حجم الصور التي تُرسل للمتصفح. لكن قبل اعتماده في سير عمل قديم، تأكد أن المكان الذي سترفع إليه يدعم الصيغة المطلوبة."),
            ("لا تحكم من الامتداد وحده", "صورة JPG بحجم 400 كيلوبايت قد تكون أفضل من PNG بحجم 3 ميجابايت لنفس الاستخدام، والعكس صحيح في بعض الرسومات. قارن الجودة والحجم معًا. الهدف ليس اختيار صيغة مشهورة، بل اختيار صيغة تخدم المحتوى."),
            ("قاعدة تحفظها", "صورة فوتوغرافية؟ ابدأ بـJPG أو WebP. شعار أو رسمة تحتاج شفافية؟ فكّر في PNG أو WebP مع الشفافية. صورة للويب؟ اختبر WebP إذا كان نظامك يدعمه. وبعدها انظر إلى الحجم الفعلي بدل الاعتماد على الاسم فقط."),
        ],
    },
    {
        "slug": "reduce-image-size-for-web",
        "title_ar": "كيف تصغّر حجم الصور للويب بدون ما تقتل جودتها؟",
        "title_en": "How to reduce image size for the web without killing quality",
        "description_ar": "طريقة عملية لتجهيز الصور للمواقع والمتاجر والملفات التعريفية مع التركيز على الحجم، الأبعاد، والجودة الفعلية.",
        "description_en": "A practical workflow for preparing images for websites and stores while balancing dimensions, file size, and visible quality.",
        "category_ar": "الصور",
        "category_en": "Images",
        "minutes": 6,
        "tool": "/tools/compress-image",
        "tool_label_ar": "جرّب ضغط الصور",
        "tool_label_en": "Try image compression",
        "sections": [
            ("ابدأ بالأبعاد قبل الجودة", "إذا كانت الصورة ستظهر بعرض 900 بكسل، فلا يوجد سبب دائمًا لرفع نسخة بعرض 6000 بكسل. تقليل الأبعاد قد يعطيك أكبر مكسب في الحجم، وغالبًا بدون فرق واضح للمستخدم عندما تكون الصورة على شاشة صغيرة."),
            ("بعدها اضبط الضغط", "الجودة ليست مفتاحًا بين جيد وسيئ فقط. هناك نقطة تبدأ بعدها الخسارة البصرية بالظهور بوضوح. جرب مستوى متوسطًا أولًا، ثم قارن الصورة عند حجم العرض الحقيقي، وليس فقط وأنت مكبرها إلى 300%."),
            ("انتبه للنص داخل الصور", "الشعارات والإنفوجرافيك ولقطات الشاشة حساسة للضغط أكثر من الصور الفوتوغرافية. إذا كان عندك نص صغير، افحصه بعد الضغط. قد تبدو الصورة ممتازة من بعيد بينما تصبح الحروف غير مريحة عند القراءة."),
            ("اسم الملف جزء من التنظيم", "قبل الرفع، سمِّ الملفات بأسماء واضحة بدل IMG_4382.jpg. الاسم المنظم يساعدك أنت في إدارة مكتبتك، ويجعل سير العمل أقل فوضى. لا تحتاج إلى حشو كلمات مفتاحية في اسم الصورة؛ الوضوح أهم."),
            ("الوصفة التي أستخدمها", "أحدد العرض المناسب، أختار صيغة مناسبة للمحتوى، أضغط بدرجة متوسطة، ثم أفتح الصورة في الحجم الذي سيشاهدها فيه المستخدم. إذا كانت جيدة هناك، انتهى الموضوع. لا تطارد أصغر رقم في خانة حجم الملف على حساب تجربة المشاهدة."),
        ],
    },
    {
        "slug": "merge-pdfs-cleanly",
        "title_ar": "دمج ملفات PDF: كيف ترتبها قبل أن تصنع ملفًا واحدًا؟",
        "title_en": "Merging PDFs: how to organize them before making one final file",
        "description_ar": "خطوات بسيطة لتجميع ملفات PDF بطريقة مرتبة، مع نصائح للصفحات المكررة، أسماء الملفات، والنسخة النهائية.",
        "description_en": "Simple steps for combining PDFs cleanly, with practical advice on order, duplicates, filenames, and final checks.",
        "category_ar": "PDF",
        "category_en": "PDF",
        "minutes": 5,
        "tool": "/tools/merge-pdf",
        "tool_label_ar": "جرّب دمج PDF",
        "tool_label_en": "Try Merge PDF",
        "sections": [
            ("رتب الملفات قبل الرفع", "إذا كانت عندك عشرات الملفات، لا تعتمد على ترتيبها العشوائي. سمِّها بأرقام مثل 01-cover.pdf و02-report.pdf و03-appendix.pdf. بهذه الطريقة تعرف الترتيب المقصود حتى قبل فتح الأداة."),
            ("راجع التكرار", "من السهل أن يكون عندك نسخة قديمة ونسخة محدثة من نفس الصفحة. قبل الدمج، افحص الأسماء والأحجام وتواريخ التعديل. ملف واحد مكرر داخل المستند النهائي قد يسبب ارتباكًا أكثر من أي خطأ تقني."),
            ("لا تنسَ الغلاف والفهارس", "إذا كان الملف النهائي سيُرسل لشخص آخر، اجعل أول صفحة تشرح ما الموجود في المستند عندما يكون ذلك منطقيًا. وإذا كان المستند طويلًا، ففهرس بسيط أو صفحة محتويات يمكن أن يوفر على القارئ وقتًا كبيرًا."),
            ("بعد الدمج: لا تغادر مباشرة", "افتح أول صفحة، صفحة في المنتصف، وآخر صفحة. تأكد أن عدد الصفحات منطقي وأن الاتجاه لم يتغير فجأة. وإذا كان الملف سيُطبع، راجع الهوامش وأرقام الصفحات أيضًا."),
            ("الفكرة كلها في النسخة النهائية", "الدمج ليس مجرد وضع ملفات خلف بعضها. هو فرصة لتحويل مجموعة ملفات مبعثرة إلى مستند واحد مفهوم. دقيقة تنظيم قبل الدمج غالبًا توفر دقائق كثيرة بعده."),
        ],
    },
    {
        "slug": "zip-files-without-the-mess",
        "title_ar": "ZIP و7Z: كيف تضغط ملفاتك وتبقى فاهم وش داخلها؟",
        "title_en": "ZIP and 7Z: how to archive files without losing track of what's inside",
        "description_ar": "دليل عملي لتنظيم الأرشيفات المضغوطة، اختيار الصيغة، وتجنب الملفات المكررة أو المجلدات المتداخلة بلا داعٍ.",
        "description_en": "A practical guide to organizing compressed archives, choosing a format, and avoiding messy nested folders and duplicates.",
        "category_ar": "الأرشيف",
        "category_en": "Archives",
        "minutes": 5,
        "tool": "/tools/create-zip",
        "tool_label_ar": "جرّب إنشاء ZIP",
        "tool_label_en": "Try creating a ZIP",
        "sections": [
            ("الضغط ليس هو التنظيم", "يمكنك ضغط ألف ملف في ZIP خلال لحظات، لكن إذا كانت الملفات أصلًا فوضوية، ستنتقل الفوضى إلى داخل الأرشيف. قبل الضغط، احذف النسخ المؤقتة، رتب المجلدات، واستخدم أسماء يمكن فهمها بعد شهر من الآن."),
            ("ZIP أم 7Z؟", "ZIP هو الخيار الأسهل للتبادل لأن دعمه واسع جدًا. 7Z قد يعطي ضغطًا أفضل في بعض الحالات، لكنه ليس الخيار الذي أختاره عندما يكون الطرف الآخر قد يستخدم جهازًا أو برنامجًا محدودًا. اسأل: هل أريد أصغر حجم، أم أريد أقل احتمال لمشكلة فتح الملف؟"),
            ("لا تضع مجلدًا داخل مجلد بلا سبب", "من أكثر الأشياء المزعجة أن تفتح archive.zip فتجد مجلدًا باسم المشروع، ثم مجلدًا آخر بنفس الاسم، ثم الملفات. إذا كنت سترسل أرشيفًا لشخص آخر، افتحه بعد إنشائه وتأكد أن أول مستوى يحتوي على الشيء الذي يتوقعه المستلم."),
            ("افحص الأرشيف بعد إنشائه", "الاختبار البسيط هو الأفضل: افتح الأرشيف، جرّب استخراج ملف أو اثنين، وتأكد من الأسماء. إذا كان الأرشيف مهمًا، احتفظ بالملفات الأصلية حتى تتأكد أن النسخة المضغوطة سليمة وقابلة للاستخراج."),
            ("الأرشيف الجيد يختصر عليك المستقبل", "الهدف من ZIP ليس فقط توفير مساحة. هو أيضًا طريقة لتسليم مجموعة ملفات كوحدة واحدة. كلما كان الهيكل واضحًا والأسماء مفهومة، صار الأرشيف مفيدًا بعد فترة طويلة من إنشائه."),
        ],
    },
    {
        "slug": "privacy-first-file-conversion",
        "title_ar": "وش يعني فعلًا تحويل ملفات مع الخصوصية أولًا؟",
        "title_en": "What does privacy-first file conversion actually mean?",
        "description_ar": "نظرة عملية على الأشياء التي تستحق الانتباه عندما ترفع ملفًا إلى أداة تحويل، من التخزين إلى النقل وسلوك الموقع.",
        "description_en": "A practical look at what matters when uploading files to an online converter, from storage and transport to site behavior.",
        "category_ar": "الخصوصية",
        "category_en": "Privacy",
        "minutes": 7,
        "tool": "/tools",
        "tool_label_ar": "تصفح الأدوات",
        "tool_label_en": "Browse tools",
        "sections": [
            ("الخصوصية ليست كلمة تسويقية", "عندما ترفع ملفًا، أنت لا ترسل صورة فقط. قد يكون الملف عقدًا، كشفًا، واجبًا جامعيًا، فاتورة، أو مستندًا فيه معلومات لا تريد أن يراها أحد. لذلك من الطبيعي أن تسأل: أين يذهب الملف؟ وكم يبقى؟ ومن يستطيع الوصول إليه؟"),
            ("ابحث عن السلوك قبل الوعود", "عبارة مثل نحن نحترم خصوصيتك جميلة، لكنها لا تكفي وحدها. اقرأ سياسة الخصوصية، راقب ما يطلبه الموقع، وتأكد هل تحتاج إلى إنشاء حساب أصلًا. الموقع الذي يشرح سلوكه بوضوح أسهل في الثقة من موقع يضع وعودًا عامة فقط."),
            ("النقل الآمن بداية وليس النهاية", "الاتصال المشفر يحمي البيانات أثناء انتقالها، لكنه لا يجيب وحده عن سؤال التخزين. لذلك من المفيد معرفة ما إذا كانت الملفات تُحفظ مؤقتًا، وكيف يتم التعامل معها بعد انتهاء العملية. كل طبقة لها سؤال مختلف."),
            ("لا ترفع أكثر مما تحتاج", "حتى مع وجود حماية جيدة، أفضل ممارسة هي تقليل البيانات من الأصل. إذا كنت تحتاج تحويل صفحة واحدة من ملف كبير، استخدم الصفحة المطلوبة بدل رفع كل المستند عندما يكون ذلك ممكنًا. وإذا كان الملف حساسًا جدًا، فالأداة المحلية قد تكون خيارًا أفضل إذا كانت متاحة لديك."),
            ("كيف نتعامل مع الفكرة في Infinity Converter؟", "Infinity Converter مبني على فكرة بسيطة: الأداة يجب أن تكون واضحة، والخصائص الحساسة لا تُفتح للعميل بلا حاجة. لهذا تبقى مفاتيح الخدمات في الخادم، وتُفصل أدوات التحويل عن مفاتيح الذكاء الاصطناعي، ونحاول أن تكون تجربة الموقع مفهومة بدل أن تعتمد على غموض تقني."),
        ],
    },
{'slug': 'doc-vs-docx-what-to-use',
  'title_ar': 'DOC أم DOCX؟ الفرق العملي قبل التحويل والمشاركة',
  'title_en': 'DOC vs DOCX: the practical difference before converting or sharing',
  'description_ar': 'تعرف متى تستخدم DOCX الحديث، ومتى تحتاج ملف DOC قديم، وكيف تقلل مشاكل التنسيق قبل التحويل إلى PDF.',
  'description_en': 'Learn when modern DOCX is the better choice, when an older DOC file still matters, and how to reduce formatting surprises '
                    'before PDF conversion.',
  'category_ar': 'المستندات',
  'category_en': 'Documents',
  'minutes': 6,
  'tool': '/tools/word-to-pdf',
  'tool_label_ar': 'جرّب Word إلى PDF',
  'tool_label_en': 'Try Word to PDF',
  'sections': [('DOCX هو الخيار الطبيعي اليوم',
                'صيغة DOCX أحدث، مبنية على حزمة ملفات منظمة، ومدعومة بشكل أفضل في الإصدارات الحديثة من برامج المكاتب. إذا كنت تنشئ مستندًا جديدًا '
                'ولا توجد متطلبات قديمة، فغالبًا DOCX هو الاختيار الأبسط للمشاركة والتحويل.'),
               ('متى يظهر DOC القديم؟',
                'قد تستلم أرشيفًا قديمًا أو نموذجًا من جهة ما زالت تستخدم DOC. لا تحتاج لتحويله لمجرد أن الامتداد قديم؛ افتحه وراجع الخطوط والجداول '
                'أولًا، ثم حوّله عندما يكون الهدف نسخة PDF ثابتة للمشاركة.'),
               ('راجع الخطوط والتخطيط قبل PDF',
                'الفرق الأكبر لا يكون دائمًا في الامتداد، بل في الخطوط والهوامش والجداول والعناصر العائمة. افتح المستند قبل التحويل، تأكد من حجم '
                'الصفحة، ثم افحص الناتج خصوصًا الصفحات التي تحتوي جداول أو صورًا.'),
               ('احتفظ بالأصل القابل للتحرير',
                'PDF ممتاز للإرسال والطباعة، لكنه ليس بديلًا عن ملف المصدر. احتفظ بنسخة DOCX أو DOC الأصلية إذا كنت تتوقع تعديلات مستقبلية، واجعل '
                'PDF نسخة التسليم أو المشاركة.')],
  'section_en': ['DOCX is the natural default today',
                 'When does old DOC still appear?',
                 'Check fonts and layout before PDF',
                 'Keep the editable source'],
  'paragraph_en': ['DOCX is the newer format and is better supported by modern office software. If you are creating a new document and have no '
                   'legacy requirement, DOCX is usually the simpler choice for editing, sharing, and conversion.',
                   'You may still receive archived documents or templates stored as DOC. There is no need to rewrite them solely because the '
                   'extension is old. Open the file, review fonts and tables, then convert it when you need a fixed PDF for distribution.',
                   'The biggest formatting surprises often come from fonts, margins, tables, and floating objects rather than the extension itself. '
                   'Review page size before conversion and inspect pages with complex layouts after the PDF is created.',
                   'PDF is excellent for delivery and printing, but it should not replace your editable source. Keep the original DOCX or DOC if '
                   'future edits are likely, and use the PDF as the sharing copy.']},
 {'slug': 'images-to-pdf-clean-document',
  'title_ar': 'كيف تجمع الصور في PDF مرتب وواضح؟',
  'title_en': 'How to combine images into a clean, readable PDF',
  'description_ar': 'خطوات عملية لترتيب صور المستندات، ضبط الاتجاه، وتقليل الحجم قبل جمعها في ملف PDF واحد.',
  'description_en': 'A practical workflow for ordering document photos, fixing orientation, and controlling size before combining them into one PDF.',
  'category_ar': 'PDF',
  'category_en': 'PDF',
  'minutes': 6,
  'tool': '/tools/jpg-to-pdf',
  'tool_label_ar': 'جرّب الصور إلى PDF',
  'tool_label_en': 'Try Images to PDF',
  'sections': [('رتب الصور قبل الرفع',
                'سمِّ الصور أو رتّبها بالترتيب الذي تريد أن تظهر به الصفحات. ابدأ بالغلاف أو الصفحة الأولى، ثم بقية الصفحات. هذه الخطوة تمنع ملف PDF '
                'صحيح تقنيًا لكنه مربك عند القراءة.'),
               ('صحح الاتجاه والقص',
                'إذا كانت إحدى الصور مقلوبة أو تحتوي مساحة كبيرة حول الورقة، عدّلها قبل الجمع. الصور المستقيمة والمقصوصة حول المحتوى تعطي PDF أصغر '
                'وأسهل للقراءة على الجوال.'),
               ('لا ترفع دقة أكبر من الحاجة',
                'صورة كاميرا ضخمة لكل صفحة قد تجعل الملف النهائي ثقيلًا بلا فائدة واضحة. حافظ على وضوح النص، لكن لا تطارد أعلى دقة إذا كان الهدف '
                'إرسال واجب أو مستند للقراءة على الشاشة.'),
               ('راجع أول وآخر صفحة',
                'بعد إنشاء PDF افتح البداية والنهاية وصفحة في الوسط. تأكد من الترتيب، الاتجاه، ووضوح أصغر نص. المراجعة السريعة تلتقط أغلب الأخطاء '
                'قبل الإرسال.')],
  'section_en': ['Order the images before uploading',
                 'Fix orientation and crop',
                 'Do not use more resolution than you need',
                 'Review the first and last page'],
  'paragraph_en': ['Name or arrange images in the exact order you want the pages to appear. Start with the cover or first page, then continue in '
                   'sequence. This prevents a technically valid PDF from becoming confusing to read.',
                   'Rotate upside-down photos and crop large empty borders before combining them. Straight, tightly framed document images create a '
                   'cleaner PDF and are usually more comfortable to view on a phone.',
                   'Huge camera images for every page can make the final document unnecessarily heavy. Preserve readable text, but do not chase '
                   'maximum resolution when the purpose is ordinary screen reading or assignment submission.',
                   'Open the beginning, the end, and one page in the middle. Confirm order, orientation, and the clarity of the smallest text. A '
                   'short review catches most mistakes before you send the file.']},
 {'slug': 'password-protected-pdf-before-sharing',
  'title_ar': 'حماية PDF بكلمة مرور: متى تفيد وماذا تتوقع؟',
  'title_en': 'Password-protecting a PDF: when it helps and what to expect',
  'description_ar': 'دليل مختصر لاستخدام كلمة مرور لفتح PDF بدون وعود مبالغ فيها، مع نصائح للتعامل الآمن مع النسخة الأصلية.',
  'description_en': 'A concise guide to using an open password on a PDF without overstating what it protects, plus safer handling of the original '
                    'file.',
  'category_ar': 'PDF',
  'category_en': 'PDF',
  'minutes': 5,
  'tool': '/tools/pdf-password-protect',
  'tool_label_ar': 'جرّب حماية PDF',
  'tool_label_en': 'Try Password Protect PDF',
  'sections': [('حدد سبب الحماية',
                'كلمة مرور فتح الملف مفيدة عندما تريد إضافة حاجز وصول لنسخة PDF تُرسل لشخص محدد. هي ليست بديلًا عن التحكم بالصلاحيات في نظام تخزين '
                'مؤسسي، لكنها طبقة مناسبة لكثير من حالات المشاركة العادية.'),
               ('استخدم كلمة مرور قوية ومختلفة',
                'تجنب الاسم أو رقم الجوال أو كلمة قصيرة. استخدم عبارة طويلة يصعب تخمينها، ولا ترسل كلمة المرور في نفس الرسالة أو القناة التي ترسل '
                'فيها الملف إذا كان المحتوى حساسًا.'),
               ('احتفظ بنسخة أصلية غير مشفرة بأمان',
                'إذا نسيت كلمة المرور قد تجعل الملف غير عملي لك أيضًا. احتفظ بالأصل في مكان موثوق، وأنشئ نسخة محمية للمشاركة بدل جعل النسخة المحمية '
                'هي النسخة الوحيدة لديك.'),
               ('اختبر الملف قبل الإرسال',
                'أغلق قارئ PDF وافتح النسخة الجديدة من جديد. تأكد أنها تطلب كلمة المرور وأن الصفحات تظهر بشكل صحيح بعد إدخالها. لا تعتمد على اسم '
                'الملف وحده كدليل أن الحماية نجحت.')],
  'section_en': ['Decide why you need protection',
                 'Use a strong, separate password',
                 'Keep a safe unencrypted original',
                 'Test the file before sending'],
  'paragraph_en': ['An open password is useful when you want an extra access barrier on a PDF sent to a specific person. It is not a replacement for '
                   'enterprise access controls, but it is a practical layer for many ordinary sharing scenarios.',
                   'Avoid names, phone numbers, and short words. Use a long phrase that is hard to guess, and do not send the password through the '
                   'same message or channel as the file when the contents are sensitive.',
                   'If you forget the password, the protected copy can become inconvenient for you as well. Keep the original in a trusted location '
                   'and create a protected sharing copy rather than making the encrypted copy your only version.',
                   'Close your PDF reader and reopen the new file. Confirm that it asks for the password and that the pages render correctly after '
                   'you enter it. The filename alone is not proof that protection was applied successfully.']},
 {'slug': 'word-to-pdf-on-mobile',
  'title_ar': 'تحويل Word إلى PDF من الجوال أو الآيباد بدون لخبطة',
  'title_en': 'Turning Word into PDF on a phone or iPad without the hassle',
  'description_ar': 'مسار بسيط لمراجعة ملف Word على شاشة صغيرة ثم تحويله والتحقق من النتيجة قبل رفعه أو إرساله.',
  'description_en': 'A simple mobile workflow for reviewing a Word file, converting it, and checking the result before upload or submission.',
  'category_ar': 'المستندات',
  'category_en': 'Documents',
  'minutes': 5,
  'tool': '/tools/word-to-pdf',
  'tool_label_ar': 'افتح Word إلى PDF',
  'tool_label_en': 'Open Word to PDF',
  'sections': [('راجع الملف قبل رفعه',
                'على الجوال قد تمر مشكلة تنسيق بدون أن تلاحظها. افتح الملف أولًا ومرر بسرعة على الصفحات، خصوصًا الجداول والصور وأرقام الصفحات، ثم '
                'ابدأ التحويل.'),
               ('استخدم نسخة الملف الفعلية',
                'إذا كان المستند داخل تطبيق سحابي، تأكد أن الملف اكتمل تنزيله قبل اختياره. بعض التطبيقات تعرض معاينة فقط، بينما أداة التحويل تحتاج '
                'الملف نفسه.'),
               ('انتظر اكتمال التنزيل',
                'بعد انتهاء التحويل اترك المتصفح يكمل تنزيل PDF قبل إغلاق الصفحة أو الانتقال لتطبيق آخر. على الشبكات البطيئة قد تظهر النتيجة قبل أن '
                'يكتمل حفظ الملف محليًا.'),
               ('افتح PDF النهائي مرة واحدة',
                'قبل رفع الواجب أو إرساله، افتح الملف الناتج وتأكد من عدد الصفحات والعناوين والجداول. هذه المراجعة أهم على الأجهزة المحمولة لأن '
                'مساحة الشاشة الصغيرة قد تخفي أخطاء في التخطيط.')],
  'section_en': ['Review the document before uploading', 'Choose the actual file', 'Let the download finish', 'Open the final PDF once'],
  'paragraph_en': ['On a phone, a layout issue can be easier to miss. Open the source document first and skim the pages, especially tables, images, '
                   'and page numbers, before starting the conversion.',
                   'If the document lives inside a cloud app, make sure it has finished downloading before you select it. Some apps show only a '
                   'preview while the converter needs access to the real file.',
                   'When conversion finishes, give the browser time to complete the PDF download before closing the page or switching apps. On a '
                   'slow connection, the result can appear before the file has finished saving locally.',
                   'Before submitting an assignment or sending the document, open the generated PDF and confirm page count, headings, and tables. '
                   'This final check matters even more on mobile because a small screen can hide layout problems.']},
 {'slug': 'best-image-format-for-print',
  'title_ar': 'JPG أم PNG للطباعة؟ اختر الصيغة حسب المحتوى',
  'title_en': 'JPG or PNG for print? Choose the format based on the content',
  'description_ar': 'فهم سريع لاختيار صيغة الصورة للطباعة، ولماذا الدقة الفعلية أهم من اسم الامتداد وحده.',
  'description_en': 'A quick guide to choosing an image format for print and why real resolution matters more than the filename extension alone.',
  'category_ar': 'الصور',
  'category_en': 'Images',
  'minutes': 6,
  'tool': '/tools/image-to-png',
  'tool_label_ar': 'جرّب تحويل الصور',
  'tool_label_en': 'Try Image Conversion',
  'sections': [('الامتداد ليس كل القصة',
                'JPG وPNG يستطيعان تخزين صورة جيدة، لكن الجودة النهائية تعتمد أيضًا على أبعاد الصورة ومصدرها وطريقة الضغط. تحويل صورة صغيرة إلى PNG '
                'لن يصنع تفاصيل لم تكن موجودة أصلًا.'),
               ('JPG مناسب لكثير من الصور الفوتوغرافية',
                'الصور التي تحتوي تدرجات كثيرة تستفيد غالبًا من JPG بحجم معقول. استخدم جودة مرتفعة إذا كانت الطباعة مهمة، وابتعد عن إعادة حفظ نفس '
                'JPG بضغط قوي عدة مرات.'),
               ('PNG ممتاز للحواف والنصوص',
                'الشعارات والرسومات ولقطات الشاشة ذات الخطوط الحادة قد تستفيد من PNG لأنه يحافظ على التفاصيل بدون ضغط فقدي. لكن ملف PNG لصورة '
                'فوتوغرافية كبيرة قد يكون أثقل بكثير من اللازم.'),
               ('احكم على الحجم المطبوع',
                'راجع أبعاد البكسل بالنسبة للحجم الذي ستطبعه. صورة تبدو ممتازة على شاشة صغيرة قد تصبح ضعيفة إذا طُبعت بحجم كبير. اطلب متطلبات '
                'المطبعة إذا كان العمل رسميًا أو عالي الجودة.')],
  'section_en': ['The extension is not the whole story',
                 'JPG suits many photographs',
                 'PNG is strong for sharp edges and text',
                 'Judge quality at the intended print size'],
  'paragraph_en': ['JPG and PNG can both hold a good image, but final quality also depends on pixel dimensions, the original source, and '
                   'compression. Converting a tiny image to PNG does not create detail that was never captured.',
                   'Photographs with many color gradients often work well as high-quality JPG files at a sensible size. If printing matters, avoid '
                   'repeatedly saving the same JPG with aggressive compression because each lossy generation can remove more detail.',
                   'Logos, diagrams, and screenshots with crisp edges can benefit from PNG because it is lossless. A large photographic PNG, '
                   'however, may be much heavier than necessary without producing a meaningful print advantage.',
                   'Compare pixel dimensions with the physical size you intend to print. An image that looks excellent on a small screen can look '
                   'soft when printed large. For professional work, ask the printer for their preferred resolution and color requirements.']},
 {'slug': 'scanned-pdf-ocr-workflow',
  'title_ar': 'أفضل مسار لملف PDF ممسوح ضوئيًا قبل OCR',
  'title_en': 'A better workflow for scanned PDFs before OCR',
  'description_ar': 'كيف تجهز PDF المصور للحصول على نص قابل للبحث بشكل أفضل، وما الذي يجب مراجعته بعد OCR.',
  'description_en': 'How to prepare a scanned PDF for better searchable text and what to review after OCR finishes.',
  'category_ar': 'OCR',
  'category_en': 'OCR',
  'minutes': 7,
  'tool': '/tools/ocr-pdf-to-searchable',
  'tool_label_ar': 'جرّب PDF قابل للبحث',
  'tool_label_en': 'Try Searchable PDF OCR',
  'sections': [('اعرف هل الملف ممسوح فعلًا',
                'حاول تحديد كلمة داخل PDF. إذا لم تستطع وكان كل شيء يتصرف كصورة، فهذا مؤشر قوي أن الملف يحتاج OCR حتى يصبح النص قابلًا للبحث أو '
                'النسخ.'),
               ('جودة الصفحة تأتي أولًا',
                'الميل والظلال والصفحات الباهتة تقلل دقة التعرف. إذا كنت تستطيع إعادة المسح، اجعل الورقة مستقيمة والإضاءة متجانسة. تحسين المصدر '
                'غالبًا أفضل من محاولة إصلاح أخطاء كثيرة بعد OCR.'),
               ('اختر اللغة الصحيحة',
                'إذا كان الملف عربيًا وإنجليزيًا، استخدم إعدادًا يدعم اللغتين عندما يكون متاحًا. اللغة الخاطئة قد تجعل المحرك يفسر أشكالًا صحيحة '
                'كحروف أو رموز غير مناسبة.'),
               ('راجع الأرقام والأسماء',
                'حتى عندما يبدو النص العام ممتازًا، افحص أسماء الأشخاص والأرقام والتواريخ والمبالغ. هذه العناصر حساسة لأي خطأ حرف واحد، لذلك لا '
                'تعتمد على OCR وحده في مستند مهم دون مراجعة.')],
  'section_en': ['Confirm that the PDF is really a scan', 'Page quality comes first', 'Choose the correct OCR language', 'Review numbers and names'],
  'paragraph_en': ['Try selecting a word inside the PDF. If you cannot and every page behaves like one image, the document is a strong candidate for '
                   'OCR so that text can become searchable or copyable.',
                   'Skew, shadows, and faint pages reduce recognition accuracy. If you can rescan the source, keep the sheet straight and lighting '
                   'even. Improving the input is often more effective than correcting a large number of OCR mistakes afterward.',
                   'For a mixed Arabic and English document, choose an OCR language setting that supports both when available. A mismatched language '
                   'can cause otherwise clear shapes to be interpreted as the wrong characters or symbols.',
                   'Even when the general text looks excellent, inspect names, numbers, dates, and monetary values. A one-character error can matter '
                   'a lot in those fields, so important OCR output should always be reviewed.']},
]

SECTION_HEADINGS_EN = {'word-to-pdf-without-losing-formatting': ['Before converting: the PDF is not the problem', 'Start with the right page size', 'Fonts and images cause most surprises', 'What about old DOC files?', 'A simple check before you send it'], 'pdf-to-word-when-it-works-best': ['First question: is the text really text?', 'Why do tables change?', 'Arabic documents deserve an extra check', 'What if the PDF is a scan?', 'When do I recommend conversion?'], 'pdf-compression-without-making-it-ugly': ['Not every PDF needs aggressive compression', 'Ask where the file will be used', 'Test the worst page', 'There is no magic ideal size', 'A practical rule'], 'ocr-for-scanned-arabic-pdfs': ['OCR is not magic image-to-text', 'Clarity matters more than file size', 'Arabic has its own challenges', 'The most useful way to use OCR', 'A quick quality test'], 'jpg-png-webp-which-image-format': ['JPG: great for photographs', 'PNG: when sharp details and transparency matter', 'WebP: a strong web option', 'Do not judge by the extension alone', 'A rule worth remembering'], 'reduce-image-size-for-web': ['Start with dimensions before quality', 'Then tune compression', 'Watch text inside images', 'Filenames help organization', 'The workflow I use'], 'merge-pdfs-cleanly': ['Organize files before uploading', 'Check for duplicates', 'Do not forget covers and contents pages', 'After merging, do not leave immediately', 'The point is the final document'], 'zip-files-without-the-mess': ['Compression is not organization', 'ZIP or 7Z?', 'Do not nest folders for no reason', 'Check the archive after creating it', 'A good archive saves future work'], 'privacy-first-file-conversion': ['Privacy is not a marketing word', 'Look at behavior, not promises', 'Secure transport is only the beginning', 'Upload no more than you need', 'How we approach the idea at Infinity Converter']}

SECTION_PARAGRAPHS_EN = {'word-to-pdf-without-losing-formatting': ['Word handles a page more flexibly than we sometimes realize. Fonts, paper size, margins, paragraph spacing, and even an image near the bottom of a page can change the final layout. A small difference after conversion does not automatically mean the PDF is broken; it often means something in the source document needs a little adjustment.', "If the document is meant for printing, make Word's page size match the PDF you expect. A4 is a sensible default for many documents. Then check the margins, especially if you have a wide table or a long header. This small step prevents a surprising number of lines from jumping to the next page.", 'Use common fonts that are actually installed on the machine preparing the document. If a formal document depends on a very unusual font, check the result carefully. Images deserve similar attention: avoid placing them in fragile spots between paragraphs that may reflow. For important files, inspect the first and last page after conversion.', "If you have an old DOC file from an older version of Microsoft Word, you do not need to rewrite it just to convert it. Infinity Converter's Word to PDF path accepts both DOC and DOCX. Very old documents can still contain unusual fonts or legacy elements, so a quick visual check remains a good habit.", 'Open the finished PDF on another device when the document matters. Search inside the text, check page numbers, and look at tables, images, and headers. A fifty-second review can save you from sending a formal document with a formatting surprise.'], 'pdf-to-word-when-it-works-best': ['Open the PDF and try selecting a word. If you can select and copy the letters, you have a text PDF and conversion is usually easier. If the entire page behaves like one image, it is probably a scan and you should expect OCR to be part of the workflow.', 'PDF is excellent at preserving a finished visual page, but it does not always store the document the way Word thinks about a document. A PDF may represent a table as positioned lines and text, while Word wants a real editable table. Complex tables can therefore need a little cleanup after conversion.', 'Arabic combines right-to-left writing with a visual order that differs from Latin text. After conversion, check headings, lists, and tables. Do not judge quality from the first simple paragraph; a page with columns or a table will reveal much more about the conversion.', 'When a PDF is a scan, OCR has to read the pixels and build new text. Results depend on scan quality, alignment, background noise, and language. A blurry scan cannot reasonably be expected to produce a perfect editable document in one click.', 'Conversion makes sense when you need to edit text, reuse paragraphs, or rebuild part of a document. If your only goal is to preserve the exact finished appearance, keeping the PDF is often the better choice.'], 'pdf-compression-without-making-it-ugly': ['Sometimes a PDF is large because it contains high-resolution images; sometimes fonts or other embedded elements contribute to the size. Aggressive compression can reduce the number, but it can also make small images harder to read. Starting with a sensible level is usually better than choosing maximum compression immediately.', 'A PDF for email is not the same as a PDF intended for professional printing. For phone reading, you can often reduce image resolution more than you could for print. If the document contains charts or screenshots, protect the text inside those images; readability matters more than chasing the smallest possible file.', 'After compression, do not only look at the cover. Visit the page with the smallest text or the most detailed image. Zoom in, search the document, and make sure graphics have not become muddy. If the difficult page still looks good, the rest is usually in a safer place.', 'There is no magic rule saying every PDF should be below a certain number of megabytes. The right target is the smallest file that still does its job. An 8 MB document that is clear can be much more useful than a 1 MB document that is unpleasant to read.', 'Keep the original before compressing an important file. Treat the compressed copy as the sharing version rather than the only copy you own. That gives you a clean route back to the original quality if you later need to print it.'], 'ocr-for-scanned-arabic-pdfs': ['When a document is scanned, the letters you see are pixels rather than actual text inside the file. OCR tries to recognize those pixels and build new text. That is why the quality of the source image matters so much.', 'A clean, straight page gives OCR a much better chance. Tilted pages, shadows, colored backgrounds, and faint printing all make recognition harder. If you can rescan a page, making it straight and clean is often more valuable than relying on heavy processing later.', 'Arabic brings its own challenges: connected letters, dots, diacritics, and mixtures of Arabic, numbers, and English can all affect recognition. It is normal to review extracted text, especially names, numbers, and dates. OCR is a way to reduce manual work, not a promise that every character is perfect.', 'OCR is useful when you want an old document to become searchable or when you need to extract a large amount of text instead of typing it. For a final document meant for publication, treat the OCR result as a draft that deserves review.', 'Test one page first. Search for a clear word, a long number, and a heading. If all three survive correctly, that is encouraging. If errors appear everywhere, improve the source images or language settings before processing the whole document.'], 'jpg-png-webp-which-image-format': ['If an image contains lots of color gradients, such as a camera photo or a landscape, JPG is often practical. It uses lossy compression, but that trade-off can produce a small file that is easy to share and serve on the web.', 'Logos, simple graphics, and some screenshots can benefit from PNG, especially when sharp edges or transparency matter. The downside is that PNG can become very large for big photographic images, where another format may be more efficient.', 'WebP is a strong web-oriented option because it can provide good compression while keeping useful visual quality. Before making it the default in an older workflow, make sure the system receiving the files supports it.', 'A 400 KB JPG can be a better choice than a 3 MB PNG for one job, while the opposite can be true for a simple graphic. Compare both visible quality and file size. The goal is not to pick the most fashionable extension; it is to pick the format that fits the content.', 'Photograph? Start with JPG or WebP. Logo or graphic that needs transparency? Consider PNG or WebP with transparency. Image for a website? Test WebP when your stack supports it. Then judge the actual result rather than the format name alone.'], 'reduce-image-size-for-web': ['If an image will be displayed at 900 pixels wide, there is not always a good reason to upload a 6000-pixel version. Reducing dimensions can produce the biggest size saving, often without a visible difference when the image is viewed at its real display size.', 'Once the dimensions are sensible, tune compression. There is usually a point where further compression becomes visibly worse. Start around the middle, then compare the image at the size a real visitor will see rather than judging only from a 300% zoom.', 'Logos, infographics, and screenshots are more sensitive to compression than ordinary photographs. If there is small text inside the image, inspect it after compression. A picture can look great from a distance while its letters become uncomfortable to read.', 'Before uploading, give files understandable names instead of IMG_4382.jpg. Clear names make your own library easier to manage. There is no need to stuff keywords into filenames; clarity is more useful.', 'I usually set a sensible display width, choose a format that fits the content, use moderate compression, and then open the image at its real viewing size. If it looks good there, I stop. Chasing the smallest number in the file-size box is not worth damaging the experience.'], 'merge-pdfs-cleanly': ['If you have many files, do not rely on a random upload order. Name them with numbers such as 01-cover.pdf, 02-report.pdf, and 03-appendix.pdf. You will know the intended order before you even open the tool.', 'It is easy to have both an old and an updated copy of the same page. Before merging, check filenames, sizes, and modification dates. One duplicate page can make the final document confusing even when the merge itself works perfectly.', 'If the final file will be sent to another person, let the first page explain what the document contains when that makes sense. For long documents, a simple contents page can save the reader a surprising amount of time.', 'Open the first page, a page in the middle, and the last page. Make sure the page count makes sense and that the orientation has not changed unexpectedly. If the file will be printed, check margins and page numbers too.', 'Merging is not only about putting files behind one another. It is a chance to turn a scattered set of documents into one understandable file. A minute of organization before merging often saves several minutes afterward.'], 'zip-files-without-the-mess': ['You can put a thousand files into a ZIP quickly, but if the source folder is messy, the mess simply moves inside the archive. Before compressing, remove temporary files, organize folders, and use names you will still understand months later.', 'ZIP is the easiest choice for exchange because support is extremely broad. 7Z can provide better compression in some cases, but it is not what I would choose when the recipient may be using a limited device or application. Ask whether you want the smallest file or the fewest opening problems.', 'One common annoyance is opening archive.zip and finding a project folder, then another folder with the same name, then the actual files. After creating an archive, open it yourself and check that its first level looks like what the recipient expects.', 'The simple test is the best one: open the archive, extract one or two files, and check their names. For an important archive, keep the originals until you have confirmed that the compressed copy is healthy and extractable.', 'The point of a ZIP file is not only saving space. It is also a way to deliver a group of files as one unit. A clear structure and understandable names make the archive useful long after it was created.'], 'privacy-first-file-conversion': ['When you upload a file, you are not just sending an image. It might be a contract, a university assignment, an invoice, or a document containing information you do not want exposed. It is reasonable to ask where the file goes, how long it stays, and who can access it.', "A phrase like 'we respect your privacy' sounds good, but it is not enough on its own. Read the privacy policy, notice what the site asks for, and check whether an account is actually necessary. A service that explains its behavior clearly is easier to evaluate than one that relies on vague promises.", 'Encrypted transport protects data while it is moving, but it does not answer the separate question of storage. It is useful to think about both layers: how the file travels and what happens to it afterward.', 'Even with good protections, the best practice is to minimize data from the start. If you only need to convert one page from a large document, use the page you need when the workflow allows it. For highly sensitive files, a local tool may be the better choice when one is available.', 'Infinity Converter follows a simple idea: the tool should be understandable, and sensitive capabilities should not be exposed to the browser without a reason. Service keys stay on the server, AI credentials are kept separate from conversion requests, and the interface should explain what it is doing instead of hiding behind technical jargon.']}
for _post in BLOG_POSTS:
    if "section_en" not in _post:
        _post["section_en"] = SECTION_HEADINGS_EN[_post["slug"]]
    if "paragraph_en" not in _post:
        _post["paragraph_en"] = SECTION_PARAGRAPHS_EN[_post["slug"]]

BLOG_BY_SLUG = {post["slug"]: post for post in BLOG_POSTS}
