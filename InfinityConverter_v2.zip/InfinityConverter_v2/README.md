# Infinity Converter 2.0

A clean, modular foundation for Infinity Converter.

## Goals
- Security-first upload validation
- Tool registry instead of duplicated tool lists
- Modular conversion engines
- Local-first processing
- Testable Flask application
- Railway-friendly deployment

## V2 rules
1. No tool gets added to the UI without a registered backend handler.
2. No uploaded file reaches a converter before validation.
3. Every heavy converter gets a timeout.
4. Every converter must return a validated output.
5. Duplicate legacy files are not carried forward.

## First deployment
- Commit this project as the new V2 structure.
- Deploy on Railway.
- Check `/api/v2/healthz`.
- Test `/api/v2/tools`.
- Then expand the tool engine module-by-module.
